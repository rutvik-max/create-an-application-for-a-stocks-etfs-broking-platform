package com.orion.templete.domain.use_case

data class DataPoint(
    val y: Double, val xLabel: String?, val yLabel: String?
)
