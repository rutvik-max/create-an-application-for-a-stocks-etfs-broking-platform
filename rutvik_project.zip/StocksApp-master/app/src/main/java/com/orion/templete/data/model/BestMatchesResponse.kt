package com.orion.templete.data.model

data class BestMatchesResponse(
    val bestMatches: List<Match>
)